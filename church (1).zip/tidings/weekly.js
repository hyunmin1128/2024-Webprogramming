function showBulletin(page) {
    const bulletinImage = document.getElementById('bulletin-image');
    bulletinImage.src = `../image/weekly/${date}_${imageNumber}.png`;
  }
  